package com.example.xcheko51x.ejemplojsoup;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    TextView tvResultado;
    Button btnObtener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResultado = findViewById(R.id.tvHtml);
        btnObtener = findViewById(R.id.btnObtener);

        btnObtener.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                obtenerWeb();
            }
        });
    }

    private void obtenerWeb() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                final StringBuilder builder = new StringBuilder();

                try {
                    Document document = Jsoup.connect("http://192.168.0.11/prueba/PruebaHtml.php").get();
                    String title = document.title();
                    Elements links = document.select("a[href]");
                    builder.append(title).append("\n");

                    for (Element link : links) {
                        builder.append("\n\n").append("Link : ").append(link.attr("href"))
                                .append("\n").append("Text : ").append(link.text())
                                .append("\n");
                    }
                } catch (IOException e) {
                    builder.append("Error : ").append(e.getMessage()).append("\n");
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvResultado.setText(builder.toString());
                    }
                });
            }
        }).start();
    }
}
